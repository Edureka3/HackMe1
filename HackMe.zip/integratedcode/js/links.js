var baseurl = "./"

var loginurl = baseurl + "logininjection_backend.php"
var logapi = baseurl + "sendlogtoapi.php"
var serverurl = baseurl + "smngmnt_backend.php"
var cookieserverurl = baseurl + "smngmnt_backendcookies.php"
var logouturl = "ba_logout_login.php?start=start"
var logoutbackend = baseurl + "ba_logout_backend.php"
var reseturl = baseurl + "resetpassword.php"